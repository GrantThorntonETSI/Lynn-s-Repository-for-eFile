function showTheTime(tzOffset) {
	//var options = { hour: 'numeric', minute: 'numeric', second: 'numeric', year: 'numeric', month: 'long', day: 'numeric', timeZoneName: 'short' };
	var thatTZ = new Date().toLocaleString('en-US', //options, 
		{timeZone: 'America/New_York'},
		{hour12: false}
		);

	var g = document.getElementsByClassName("datesigned");

	var t = document.getElementById("tz").innerHTML = thatTZ + " E.T.";
	g[0].value += t;
	//console.log(thatTZ.toLocaleString('en-US', {timeZone: 'America/Los_Angeles'}));
}

function showTheTimeTwo(tzOffset) {
	//var options = { hour: 'numeric', minute: 'numeric', second: 'numeric', year: 'numeric', month: 'long', day: 'numeric', timeZoneName: 'short' };
	var thatTZ = new Date().toLocaleString('en-US', //options, 
		{timeZone: 'America/New_York'},
		{hour12: false}
		);

	var g = document.getElementsByClassName("datesigned");

	var t = document.getElementById("tz2").innerHTML = thatTZ + " E.T.";
	g[1].value += t;
	//console.log(thatTZ.toLocaleString('en-US', {timeZone: 'America/Los_Angeles'}));
}